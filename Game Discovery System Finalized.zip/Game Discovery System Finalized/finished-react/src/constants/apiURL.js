// normal url text export as constant
export const gamesURL = `games`;
export const genresURL = `genres`;
