import loader from "../assets/images/loader.gif";

export {loader};