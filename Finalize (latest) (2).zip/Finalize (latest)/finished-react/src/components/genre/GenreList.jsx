import React from 'react';
import './GenreList.css';

const GenreList = () => {
  return (
    <div className='GenreListWrapper'>
    </div>
  )
}

export default GenreList;